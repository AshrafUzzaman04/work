const header = document.querySelectorAll(".header");
const details = document.querySelectorAll(".details");

for (let i = 0; i < header.length; i++) {
  header[i].addEventListener("click", () => {
    for (let j = 0; j < header.length; j++) {
      if (i === j) {
        if (header[j].classList.contains("active")) {
          header[j].classList.remove("active");
          details[j].classList.add("displayNone");
        } else {
          header[j].classList.add("active");
          details[j].classList.remove("displayNone");
        }
      } else {
        header[j].classList.remove("active");
        details[j].classList.add("displayNone");
      }
    }
  });
}
